def main():
    print("Hello from dynamic-risk-assessment-sytem!")


if __name__ == "__main__":
    main()
